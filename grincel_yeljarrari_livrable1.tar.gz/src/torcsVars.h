#ifndef TORCSVARS_H
#define TORCSVARS_H


/* Function prototypes */

int initTorcsVars ();
char * typeToLLVM (int CType);


char * getLLVMVarLoading();
char * getLLVMVarStoring();

#endif
