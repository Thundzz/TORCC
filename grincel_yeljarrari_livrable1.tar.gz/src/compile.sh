#!/bin/bash

make

echo "Compiling  $1, output file : $2"
./parse $1 > $2
sleep 0.5

echo "Printing the output file : "
cat $2