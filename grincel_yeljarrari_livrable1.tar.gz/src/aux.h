#ifndef AUX_H
#define AUX_H


char * strFusion (char * str, char * toAppend);


#endif
